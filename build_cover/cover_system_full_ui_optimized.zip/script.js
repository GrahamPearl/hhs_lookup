// ================= DATA =================
const PREFIX = "teacher_";

let allTeachers = {};
let history = [];
let historyStats = {};
let availabilityCache = {};
let coverAssignments = {};
let absentTeachers = [];

// ================= LOAD =================
function loadAllTeachers() {
  allTeachers = {};
  Object.keys(localStorage).forEach(k => {
    if (k.startsWith(PREFIX)) {
      const name = k.replace(PREFIX, "");
      allTeachers[name] = JSON.parse(localStorage.getItem(k));
    }
  });
}

function loadHistory() {
  history = JSON.parse(localStorage.getItem("coverHistory") || "[]");
}

function buildHistoryStats() {
  historyStats = {};
  history.forEach(h => {
    if (!historyStats[h.coverTeacher]) {
      historyStats[h.coverTeacher] = { total: 0 };
    }
    historyStats[h.coverTeacher].total++;
  });
}

// ================= LOGIC =================
function getAvailableTeachers(period, day) {
  const key = period + "-" + day;
  if (availabilityCache[key]) return availabilityCache[key];

  let list = [];

  Object.keys(allTeachers).forEach(name => {
    if (absentTeachers.includes(name)) return;

    let entry = allTeachers[name].entries?.find(e => e.row == day && e.col == period);
    if (entry && (entry.type === "free" || entry.type === "meeting")) {
      let total = historyStats[name]?.total || 0;
      list.push({ name, total });
    }
  });

  list.sort((a,b)=>a.total-b.total);
  availabilityCache[key] = list;
  return list;
}

// ================= UI =================
function renderGrid() {
  availabilityCache = {};
  const day = parseInt(document.getElementById("absenceDaySelect").value);

  let html = "<table class='table table-bordered'>";
  html += "<tr><th>Teacher</th><th>P</th><th>Assign</th></tr>";

  let unassigned = 0;

  absentTeachers.forEach(teacher=>{
    let data = allTeachers[teacher];
    if (!data) return;

    data.entries.filter(e=>e.row==day && e.type==="lesson").forEach(e=>{
      const key = teacher+":"+day+"-"+e.col;
      let assigned = coverAssignments[key];

      if(!assigned) unassigned++;

      html += `<tr class="${!assigned?'table-warning':''}">
      <td>${teacher}</td>
      <td>${e.col+1}</td>
      <td><div class="drop-zone ${!assigned?'warn':''}" data-key="${key}">
      ${assigned || "Drop here"}
      </div></td></tr>`;
    });
  });

  html += "</table>";
  document.getElementById("coverGrid").innerHTML = html;
  document.getElementById("summary").innerHTML = "Unassigned: "+unassigned;

  attachDrop();
  renderAvailable(day);
}

function renderAvailable(day){
  let html="<table class='table table-sm'><tr><th>P</th><th>Teachers</th></tr>";

  for(let p=0;p<6;p++){
    let avail=getAvailableTeachers(p,day);
    html+="<tr><td>"+(p+1)+"</td><td>";

    avail.forEach(t=>{
      html+=`<span class="badge bg-primary me-1 avail-badge" draggable="true" title="Total:${t.total}">${t.name}</span>`;
    });

    html+="</td></tr>";
  }

  html+="</table>";
  document.getElementById("availableCoverList").innerHTML=html;

  document.querySelectorAll(".avail-badge").forEach(el=>{
    el.ondragstart=e=>e.dataTransfer.setData("text",el.innerText);
  });
}

// ================= EVENTS =================
function attachDrop(){
  document.querySelectorAll(".drop-zone").forEach(z=>{
    z.ondragover=e=>e.preventDefault();
    z.ondrop=e=>{
      e.preventDefault();
      const t=e.dataTransfer.getData("text");
      const key=z.dataset.key;
      coverAssignments[key]=t;
      history.push({coverTeacher:t});
      buildHistoryStats();
      renderGrid();
    };
  });
}

// ================= NAV ACTIONS =================
document.getElementById("autoAssignBtn").onclick=()=>{
  const day=parseInt(document.getElementById("absenceDaySelect").value);

  absentTeachers.forEach(t=>{
    let data=allTeachers[t];
    if(!data)return;

    data.entries.filter(e=>e.row==day && e.type==="lesson").forEach(e=>{
      let key=t+":"+day+"-"+e.col;
      if(coverAssignments[key])return;

      let avail=getAvailableTeachers(e.col,day);
      if(avail.length) coverAssignments[key]=avail[0].name;
    });
  });

  renderGrid();
};

document.getElementById("printBtn").onclick=()=>window.print();

document.getElementById("exportBtn").onclick=()=>{
  let blob=new Blob([JSON.stringify({coverAssignments,history})],{type:"application/json"});
  let a=document.createElement("a");
  a.href=URL.createObjectURL(blob);
  a.download="backup.json";
  a.click();
};

document.getElementById("importBtn").onclick=()=>{
  document.getElementById("importFile").click();
};

document.getElementById("importFile").onchange=async(e)=>{
  let file=e.target.files[0];
  let txt=await file.text();
  let data=JSON.parse(txt);
  coverAssignments=data.coverAssignments||{};
  history=data.history||[];
  buildHistoryStats();
  renderGrid();
};

document.getElementById("absenceDaySelect").onchange=renderGrid;

// ================= INIT =================
function init(){
  loadAllTeachers();
  loadHistory();
  buildHistoryStats();
  absentTeachers=Object.keys(allTeachers).slice(0,3);
  renderGrid();
}

init();
