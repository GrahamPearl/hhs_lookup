// =========================
// OPTIMIZED DATA LAYER
// =========================
const PREFIX = "teacher_";

let allTeachers = {};
let history = [];
let historyStats = {};
let availabilityCache = {};
let coverAssignments = {};
let absentTeachers = [];

// Load all teachers once
function loadAllTeachers() {
  allTeachers = {};
  Object.keys(localStorage).forEach(k => {
    if (k.startsWith(PREFIX)) {
      const name = k.replace(PREFIX, "");
      allTeachers[name] = JSON.parse(localStorage.getItem(k));
    }
  });
}

// Load history once
function loadHistory() {
  history = JSON.parse(localStorage.getItem("coverHistory") || "[]");
}

// Precompute stats
function buildHistoryStats() {
  historyStats = {};
  history.forEach(h => {
    if (!historyStats[h.coverTeacher]) {
      historyStats[h.coverTeacher] = { total: 0, weekly: {} };
    }
    historyStats[h.coverTeacher].total++;
    historyStats[h.coverTeacher].weekly[h.week] =
      (historyStats[h.coverTeacher].weekly[h.week] || 0) + 1;
  });
}

// =========================
// LOGIC LAYER
// =========================
function getAvailableTeachers(period, day) {
  const key = period + "-" + day;
  if (availabilityCache[key]) return availabilityCache[key];

  let list = [];

  Object.keys(allTeachers).forEach(name => {
    if (absentTeachers.includes(name)) return;

    let entry = allTeachers[name].entries?.find(e => e.row == day && e.col == period);
    if (entry && (entry.type === "free" || entry.type === "meeting")) {
      let stats = historyStats[name] || { total: 0 };
      list.push({
        name,
        totalCovers: stats.total || 0
      });
    }
  });

  list.sort((a, b) => a.totalCovers - b.totalCovers);

  availabilityCache[key] = list;
  return list;
}

// =========================
// UI LAYER (Optimized)
// =========================
function renderGrid() {
  availabilityCache = {};

  const day = parseInt(document.getElementById("absenceDaySelect").value);
  const grid = document.getElementById("coverGrid");

  // Build HTML string (faster than DOM ops)
  let html = "<table class='table table-bordered'>";
  html += "<tr><th>Teacher</th><th>Period</th><th>Assign</th></tr>";

  absentTeachers.forEach(teacher => {
    let data = allTeachers[teacher];
    if (!data) return;

    data.entries.filter(e => e.row == day).forEach(e => {
      if (e.type !== "lesson") return;

      const key = teacher + ":" + day + "-" + e.col;

      html += `
      <tr>
        <td>${teacher}</td>
        <td>${e.col + 1}</td>
        <td>
          <div class="drop-zone" data-key="${key}">
            ${coverAssignments[key] || "Drop here"}
          </div>
        </td>
      </tr>`;
    });
  });

  html += "</table>";
  grid.innerHTML = html;

  attachDropEvents();
  renderAvailable(day);
}

function renderAvailable(day) {
  let html = "<table class='table table-sm'><tr><th>Period</th><th>Teachers</th></tr>";

  for (let p = 0; p < 6; p++) {
    let avail = getAvailableTeachers(p, day);
    html += "<tr><td>" + (p+1) + "</td><td>";

    avail.forEach(t => {
      html += `<span class="badge bg-primary me-1 avail-badge" draggable="true">${t.name}</span>`;
    });

    html += "</td></tr>";
  }

  html += "</table>";
  document.getElementById("availableCoverList").innerHTML = html;

  document.querySelectorAll(".avail-badge").forEach(el => {
    el.ondragstart = e => e.dataTransfer.setData("text", e.target.innerText);
  });
}

// =========================
// EVENTS
// =========================
function attachDropEvents() {
  document.querySelectorAll(".drop-zone").forEach(zone => {

    zone.ondragover = e => e.preventDefault();

    zone.ondragenter = () => zone.classList.add("drop-hover");
    zone.ondragleave = () => zone.classList.remove("drop-hover");

    zone.ondrop = e => {
      e.preventDefault();
      zone.classList.remove("drop-hover");

      const teacher = e.dataTransfer.getData("text");
      const key = zone.dataset.key;

      coverAssignments[key] = teacher;
      renderGrid();
    };
  });
}

// =========================
// INIT
// =========================
function init() {
  loadAllTeachers();
  loadHistory();
  buildHistoryStats();

  // Demo absent teachers (can be replaced)
  absentTeachers = Object.keys(allTeachers).slice(0, 2);

  renderGrid();
}

document.getElementById("absenceDaySelect").onchange = renderGrid;

init();
