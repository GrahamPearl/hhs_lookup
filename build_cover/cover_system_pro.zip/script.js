const PREFIX="teacher_";
let assignments={}, tallies={};

document.getElementById("fileInput").addEventListener("change",async e=>{
 let files=e.target.files;
 for(let f of files){
  if(!f.name.endsWith(".json")) continue;
  let txt=await f.text();
  let data=JSON.parse(txt);
  let name=data.teacherName||f.name.replace(".json","");
  localStorage.setItem(PREFIX+name, JSON.stringify(data));
 }
 loadTeachers();
});

function loadTeachers(){
 let sel=document.getElementById("teacherSelect");
 sel.innerHTML="";
 Object.keys(localStorage).forEach(k=>{
  if(k.startsWith(PREFIX)){
   let name=k.replace(PREFIX,"");
   let o=document.createElement("option");
   o.value=name;
   o.textContent=name;
   sel.appendChild(o);
  }
 });
}

function getData(name){
 return JSON.parse(localStorage.getItem(PREFIX+name));
}

function generate(){
 let t=document.getElementById("teacherSelect").value;
 let d=parseInt(document.getElementById("daySelect").value);
 let absent=getData(t);

 let grid=document.getElementById("grid");
 grid.innerHTML="";

 absent.entries.filter(e=>e.row==d).forEach(e=>{
  let div=document.createElement("div");
  div.className="cell "+e.type;
  let key=d+"-"+e.col;

  div.innerHTML=`<b>Period ${e.col+1}</b><br>${e.subject||e.type}`;

  if(e.type==="lesson"){
   let drop=document.createElement("div");
   drop.className="mt-2 border p-2";
   drop.ondragover=x=>x.preventDefault();
   drop.ondrop=ev=>{
     let teacher=ev.dataTransfer.getData("text");
     assignments[key]=teacher;
     tallies[teacher]=(tallies[teacher]||0)+1;
     generate();
   };

   if(assignments[key]){
    drop.innerHTML=`${assignments[key]} <button onclick="undo('${key}')">Undo</button>`;
   } else {
    drop.innerText="Drop teacher";
   }

   div.appendChild(drop);
  }

  grid.appendChild(div);
 });

 renderPool();
}

function renderPool(){
 let grid=document.getElementById("grid");
 let pool=document.createElement("div");
 pool.innerHTML="<h5>Teachers</h5>";

 Object.keys(localStorage).forEach(k=>{
  if(!k.startsWith(PREFIX)) return;
  let name=k.replace(PREFIX,"");

  let d=document.createElement("div");
  d.draggable=true;
  d.innerText=name+" ("+(tallies[name]||0)+")";
  d.ondragstart=e=>e.dataTransfer.setData("text",name);

  pool.appendChild(d);
 });

 grid.appendChild(pool);
}

function undo(key){
 delete assignments[key];
 generate();
}

function savePlan(){
 localStorage.setItem("cover_assignments", JSON.stringify(assignments));
 alert("Saved");
}

function printPlan(){
 window.print();
}

function generateReport(){
 let div=document.getElementById("report");
 let html="<h3>Usage Report</h3>";
 Object.keys(tallies).forEach(t=>{
  html+=`<div>${t}: ${tallies[t]} covers</div>`;
 });
 div.innerHTML=html;
}

loadTeachers();
