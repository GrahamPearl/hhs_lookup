// PERFORMANCE + UX OPTIMIZED VERSION

const STORAGE_PREFIX = "teacher_";
let timetableConfig = { rows:0, cols:0 };
let timetableData = {};
let cellMap = {};
let teacherCache = {};
let saveTimeout;

const table = document.getElementById("timetableTable");

function getKey(r,c){ return r+"-"+c; }

function autoSave(){
 clearTimeout(saveTimeout);
 saveTimeout = setTimeout(()=>{
   document.getElementById("saveStatus").innerText="Auto-saved";
   save();
 },1000);
}

function buildTable(){
 cellMap = {};
 table.innerHTML="";
 let frag = document.createDocumentFragment();

 for(let r=0;r<timetableConfig.rows;r++){
   let tr=document.createElement("tr");

   for(let c=0;c<timetableConfig.cols;c++){
     let td=document.createElement("td");
     td.className="timetable-cell";
     td.dataset.row=r;
     td.dataset.col=c;
     td.innerText="+";

     cellMap[getKey(r,c)] = td;
     tr.appendChild(td);
   }
   frag.appendChild(tr);
 }

 table.appendChild(frag);
}

table.addEventListener("click", e=>{
 let cell = e.target.closest(".timetable-cell");
 if(!cell) return;

 let r=cell.dataset.row;
 let c=cell.dataset.col;

 let type = prompt("Type: lesson/meeting/free","lesson");
 timetableData[getKey(r,c)]={type};

 renderCell(r,c);
 autoSave();
});

function renderCell(r,c){
 let cell = cellMap[getKey(r,c)];
 let entry = timetableData[getKey(r,c)];

 cell.className="timetable-cell";

 if(!entry){ cell.innerText="+"; return;}

 if(entry.type==="free"){
   cell.classList.add("free");
   cell.innerText="Free";
 }
 else if(entry.type==="meeting"){
   cell.classList.add("meeting");
   cell.innerText="Meeting";
 }
 else{
   cell.classList.add("lesson");
   cell.innerText="Lesson";
 }
}

function save(){
 let name=document.getElementById("teacherNameInput").value;
 localStorage.setItem(STORAGE_PREFIX+name, JSON.stringify({
   config:timetableConfig,
   data:timetableData
 }));
}

function load(){
 let name=document.getElementById("teacherSelect").value;
 let data=JSON.parse(localStorage.getItem(STORAGE_PREFIX+name));
 timetableConfig=data.config;
 timetableData=data.data||{};
 buildTable();
 Object.keys(timetableData).forEach(k=>{
   let [r,c]=k.split("-");
   renderCell(r,c);
 });
}

function computeAvailability(absent, day){
 let results={};

 for(let key in localStorage){
   if(!key.startsWith(STORAGE_PREFIX)) continue;
   if(key===STORAGE_PREFIX+absent) continue;

   let data=JSON.parse(localStorage.getItem(key));
   let map=data.data||{};

   for(let c=0;c<data.config.cols;c++){
     let k=day+"-"+c;
     if(map[k] && map[k].type==="free"){
       if(!results[c]) results[c]=[];
       results[c].push(key.replace(STORAGE_PREFIX,""));
     }
   }
 }

 return results;
}

function renderAvailability(res){
 let div=document.getElementById("availabilityResults");
 let html="";

 Object.keys(res).forEach(p=>{
   html+=`<div><b>P${parseInt(p)+1}</b>: ${res[p].length} teachers</div>`;
 });

 div.innerHTML=html;
}

document.getElementById("generateBtn").onclick=()=>{
 timetableConfig.rows=parseInt(rowsInput.value);
 timetableConfig.cols=parseInt(colsInput.value);
 buildTable();
};

document.getElementById("saveBtn").onclick=save;
document.getElementById("loadBtn").onclick=load;

document.getElementById("checkAvailabilityBtn").onclick=()=>{
 let teacher=document.getElementById("absenceTeacherSelect").value;
 let day=parseInt(document.getElementById("absenceDaySelect").value);
 renderAvailability(computeAvailability(teacher,day));
};
