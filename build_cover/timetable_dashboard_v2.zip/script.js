const STORAGE_PREFIX="teacher_";
let timetableConfig={rows:0,cols:0};
let timetableData={};
let cellMap={};

const table=document.getElementById("timetableTable");

function key(r,c){return r+"-"+c;}

function buildTable(){
 table.innerHTML="";
 cellMap={};
 let frag=document.createDocumentFragment();

 for(let r=0;r<timetableConfig.rows;r++){
  let tr=document.createElement("tr");
  for(let c=0;c<timetableConfig.cols;c++){
    let td=document.createElement("td");
    td.className="timetable-cell";
    td.dataset.row=r;
    td.dataset.col=c;
    td.innerText="+";
    cellMap[key(r,c)]=td;
    tr.appendChild(td);
  }
  frag.appendChild(tr);
 }
 table.appendChild(frag);
}

table.addEventListener("click",e=>{
 let cell=e.target.closest(".timetable-cell");
 if(!cell)return;

 let r=cell.dataset.row;
 let c=cell.dataset.col;

 let type=prompt("lesson/meeting/free","lesson");
 timetableData[key(r,c)]={type};
 renderCell(r,c);
});

function renderCell(r,c){
 let cell=cellMap[key(r,c)];
 let entry=timetableData[key(r,c)];
 cell.className="timetable-cell";

 if(!entry){cell.innerText="+";return;}
 if(entry.type==="free"){cell.classList.add("free");cell.innerText="Free";}
 else if(entry.type==="meeting"){cell.classList.add("meeting");cell.innerText="Meeting";}
 else{cell.classList.add("lesson");cell.innerText="Lesson";}
}

function save(){
 let name=document.getElementById("teacherNameInput").value;
 localStorage.setItem(STORAGE_PREFIX+name,JSON.stringify({
   config:timetableConfig,data:timetableData
 }));
 refreshTeachers();
}

function refreshTeachers(){
 let select=document.getElementById("absenceTeacherSelect");
 select.innerHTML="";
 Object.keys(localStorage).forEach(k=>{
   if(k.startsWith(STORAGE_PREFIX)){
     let opt=document.createElement("option");
     opt.value=k.replace(STORAGE_PREFIX,"");
     opt.textContent=opt.value;
     select.appendChild(opt);
   }
 });
}

function computeAvailability(absent,day){
 let scores={};
 let availability={};

 Object.keys(localStorage).forEach(k=>{
   if(!k.startsWith(STORAGE_PREFIX))return;
   let name=k.replace(STORAGE_PREFIX,"");
   if(name===absent)return;

   let data=JSON.parse(localStorage.getItem(k));
   let freeCount=0;

   for(let c=0;c<data.config.cols;c++){
     let entry=data.data[day+"-"+c];
     if(entry && entry.type==="free"){
       freeCount++;
       if(!availability[c])availability[c]=[];
       availability[c].push(name);
     }
   }
   scores[name]=freeCount;
 });

 return {availability,scores};
}

function suggestBest(scores){
 let best=null;
 let max=-1;
 Object.keys(scores).forEach(t=>{
   if(scores[t]>max){
     max=scores[t];
     best=t;
   }
 });
 return {best,max};
}

function renderAvailability(res){
 let div=document.getElementById("availabilityResults");
 let bestDiv=document.getElementById("bestSuggestion");

 let html="";
 Object.keys(res.availability).forEach(p=>{
   html+=`<div>P${parseInt(p)+1}: ${res.availability[p].join(", ")}</div>`;
 });
 div.innerHTML=html;

 let best=suggestBest(res.scores);
 if(best.best){
   bestDiv.classList.remove("d-none");
   bestDiv.innerText="Best cover: "+best.best+" ("+best.max+" free periods)";
 }
}

document.getElementById("checkAvailabilityBtn").onclick=()=>{
 let t=document.getElementById("absenceTeacherSelect").value;
 let d=parseInt(document.getElementById("absenceDaySelect").value||0);
 renderAvailability(computeAvailability(t,d));
};

document.getElementById("generateBtn").onclick=()=>{
 timetableConfig.rows=parseInt(rowsInput.value);
 timetableConfig.cols=parseInt(colsInput.value);
 buildTable();
};

document.getElementById("saveBtn").onclick=save;

// BULK IMPORT
document.getElementById("bulkImportBtn").onclick=()=>{
 document.getElementById("bulkImportInput").click();
};

document.getElementById("bulkImportInput").addEventListener("change",async e=>{
 let files=Array.from(e.target.files);
 let status=document.getElementById("importStatus");

 let count=0;
 for(let f of files){
   if(!f.name.endsWith(".json"))continue;

   let text=await f.text();
   let data=JSON.parse(text);

   let name=data.teacherName || f.name.replace(".json","");
   localStorage.setItem(STORAGE_PREFIX+name,JSON.stringify(data));
   count++;

   status.innerText="Imported "+count+" files...";
   await new Promise(r=>setTimeout(r,0));
 }

 status.innerText="Done importing "+count+" files.";
 refreshTeachers();
});

refreshTeachers();
