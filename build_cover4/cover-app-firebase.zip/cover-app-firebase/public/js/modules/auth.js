// auth.js — Session 2 (email-link sign-in)
// Not yet implemented.
// Context: cover-app-firebase-migration-plan.md, §7 row for Session 2.
// Paste that row (or the whole file) into a new chat to build this module —
// no need to re-share the rest of the app.

export {};
