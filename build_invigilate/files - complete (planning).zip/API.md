# Scheduling Engine API Reference

## 📚 Complete Function Reference

The Exam Scheduler includes a powerful scheduling engine with 38+ functions organized in 8 modules. This document covers all public APIs.

---

## 🔧 Quick Start

### Load Both Parts
```html
<script src="scheduling-engine-part1.js"></script>
<script src="scheduling-engine-part2.js"></script>
```

### Basic Usage
```javascript
// Your data
const assignments = [
  { date: '2026-05-25', session: 1, grade: '12', exam: 'Accounting', venue: '1', timeshift: 2.5, educator: null },
  { date: '2026-05-25', session: 1, grade: '12', exam: 'Economics', venue: '2', timeshift: 2.5, educator: null },
  // ... more assignments
];

const teachers = [
  { name: 'Smith', registerClass: 'Grade 12', is_zulu: false },
  { name: 'Jones', registerClass: 'Grade 12', is_zulu: false },
  { name: 'Nkosi', registerClass: 'Grade 10', is_zulu: true }
];

// Run scheduling
const result = scheduleAssignments(assignments, teachers);

console.log(result.statistics);
console.log(result.warnings);
```

---

## MODULE 1: INPUT VALIDATION & PREPARATION

### validateAssignments(assignments)
Validates the structure and content of assignments array.

**Parameters:**
- `assignments` (Array) - Array of assignment objects

**Returns:**
```javascript
{
  isValid: boolean,
  errors: Array<string>
}
```

**Example:**
```javascript
const result = validateAssignments([
  { date: '2026-05-25', session: 1, grade: '12', exam: 'Math', venue: '1', timeshift: 2.5, educator: null }
]);
// → { isValid: true, errors: [] }
```

**What It Checks:**
- ✅ Is array
- ✅ Not empty
- ✅ All required fields present
- ✅ Correct data types
- ✅ Valid values

---

### validateTeachers(teachers)
Validates teacher array structure.

**Parameters:**
- `teachers` (Array) - Array of teacher objects

**Returns:**
```javascript
{
  isValid: boolean,
  errors: Array<string>
}
```

**Example:**
```javascript
const result = validateTeachers([
  { name: 'Smith', registerClass: 'Grade 12', is_zulu: false }
]);
// → { isValid: true, errors: [] }
```

---

### identifyEmptySlots(assignments)
Finds all assignments without educators.

**Parameters:**
- `assignments` (Array)

**Returns:**
- Array of indices where educator is null/empty

**Example:**
```javascript
const emptyIndices = identifyEmptySlots(assignments);
// → [1, 3, 5, 8]
```

---

### identifyPreassignedSlots(assignments)
Finds all assignments that already have educators assigned.

**Parameters:**
- `assignments` (Array)

**Returns:**
- Array of indices where educator exists

**Example:**
```javascript
const assignedIndices = identifyPreassignedSlots(assignments);
// → [0, 2, 4, 6]
```

---

### normalizeDates(assignments)
Converts all dates to consistent YYYY-MM-DD format.

**Parameters:**
- `assignments` (Array)

**Returns:**
- Array with normalized dates (new array, doesn't mutate input)

**Example:**
```javascript
const normalized = normalizeDates(assignments);
// Converts Excel dates, Date objects, and strings to 'YYYY-MM-DD'
```

---

### buildTeacherIndex(teachers)
Creates fast lookup Map for teachers by name.

**Parameters:**
- `teachers` (Array)

**Returns:**
- Map<string, Object> - Map of teacherName → teacherObject

**Example:**
```javascript
const index = buildTeacherIndex(teachers);
const teacher = index.get('Smith');
// → { name: 'Smith', registerClass: 'Grade 12', ... }
```

---

## MODULE 2: CONFLICT DETECTION

### isDoubleBooked(teacherName, date, session, assignments)
Checks if teacher is already assigned to date+session.

**Parameters:**
- `teacherName` (string)
- `date` (string) - 'YYYY-MM-DD' format
- `session` (number)
- `assignments` (Array)

**Returns:**
- boolean

**Example:**
```javascript
const isBooked = isDoubleBooked('Smith', '2026-05-25', 1, assignments);
// → true (Smith already has exam in session 1 on that date)
```

---

### getTeacherScheduleOnDate(teacherName, date, assignments)
Gets all assignments for teacher on specific date.

**Parameters:**
- `teacherName` (string)
- `date` (string) - 'YYYY-MM-DD'
- `assignments` (Array)

**Returns:**
- Array of assignment objects

**Example:**
```javascript
const schedule = getTeacherScheduleOnDate('Smith', '2026-05-25', assignments);
// → [{ date: '2026-05-25', session: 1, exam: 'Accounting', ... }, ...]
```

---

### buildBookingMap(assignments)
Creates efficient booking lookup structure.

**Parameters:**
- `assignments` (Array)

**Returns:**
```javascript
{
  "Smith": {
    "2026-05-25_1": 1,
    "2026-05-25_2": 1
  },
  "Jones": {
    "2026-05-25_1": 2
  }
}
```

---

### validateConflictFree(assignments)
Checks entire schedule for conflicts.

**Parameters:**
- `assignments` (Array)

**Returns:**
```javascript
{
  hasConflicts: boolean,
  conflicts: Array<{educator, dateSession, count}>
}
```

**Example:**
```javascript
const check = validateConflictFree(assignments);
if (check.hasConflicts) {
  console.log('Conflicts found:', check.conflicts);
  // → [{ educator: 'Smith', dateSession: '2026-05-25_1', count: 2 }]
}
```

---

## MODULE 3: WORKLOAD MANAGEMENT

### calculateTeacherHours(teacherName, assignments)
Sums all hours assigned to teacher.

**Parameters:**
- `teacherName` (string)
- `assignments` (Array)

**Returns:**
- number (total hours)

**Example:**
```javascript
const hours = calculateTeacherHours('Smith', assignments);
// → 18.5
```

---

### buildWorkloadMap(assignments, teachers)
Creates detailed workload tracking structure.

**Parameters:**
- `assignments` (Array)
- `teachers` (Array)

**Returns:**
```javascript
{
  "Smith": {
    name: "Smith",
    grade: "Grade 12",
    is_zulu: false,
    totalHours: 18.5,
    assignments: [0, 3, 5],
    dailyLoad: {
      "2026-05-25": 5.5,
      "2026-05-26": 13.0
    },
    sessionLoad: {
      "2026-05-25_1": 2.5,
      "2026-05-25_2": 3.0
    },
    bookings: {
      "2026-05-25_1": 1,
      "2026-05-25_2": 1
    }
  },
  // ... more teachers
}
```

---

### getTeacherWorkload(teacherName, workloadMap)
Retrieves workload for one teacher.

**Parameters:**
- `teacherName` (string)
- `workloadMap` (Object) - from buildWorkloadMap()

**Returns:**
- Teacher workload object

---

### calculateWorkloadVariance(workloadMap)
Measures fairness of workload distribution.

**Parameters:**
- `workloadMap` (Object)

**Returns:**
- number (standard deviation)

**Example:**
```javascript
const variance = calculateWorkloadVariance(workloadMap);
// → 3.2 (lower = more balanced)
```

---

### findLeastLoadedTeacher(teachers, workloadMap)
Finds teacher with lowest hours assigned.

**Parameters:**
- `teachers` (Array)
- `workloadMap` (Object)

**Returns:**
- Teacher object | null

**Example:**
```javascript
const teacher = findLeastLoadedTeacher(teachers, workloadMap);
// → { name: 'Jones', registerClass: 'Grade 12', totalHours: 5 }
```

---

## MODULE 4: ELIGIBILITY & FILTERING

### isTeacherEligible(teacherName, assignment, assignments, teacherIndex, workloadMap)
Checks all hard constraints for teacher-assignment pair.

**Parameters:**
- `teacherName` (string)
- `assignment` (Object) - Single assignment
- `assignments` (Array)
- `teacherIndex` (Map)
- `workloadMap` (Object)

**Returns:**
- boolean

**Hard Constraints Checked:**
- ✅ No double-booking
- ✅ Availability date range
- ✅ Language requirement (Zulu)

---

### filterEligibleTeachers(assignment, assignments, teachers, teacherIndex, workloadMap)
Gets all teachers who can do this assignment.

**Parameters:**
- `assignment` (Object)
- `assignments` (Array)
- `teachers` (Array)
- `teacherIndex` (Map)
- `workloadMap` (Object)

**Returns:**
- Array of eligible teacher names

**Example:**
```javascript
const eligible = filterEligibleTeachers(assignment, assignments, teachers, teacherIndex, workloadMap);
// → ['Smith', 'Jones', 'Williams']
```

---

### filterPreferredTeachers(assignment, teachers)
Gets teachers whose grade matches assignment.

**Parameters:**
- `assignment` (Object)
- `teachers` (Array)

**Returns:**
- Array of teacher names with matching grade

**Example:**
```javascript
const preferred = filterPreferredTeachers(assignment, teachers);
// → ['Smith', 'Jones']  // Grade 12 teachers for Grade 12 exam
```

---

### buildEligibilityMatrix(assignments, teachers, teacherIndex, emptySlots, workloadMap)
Creates analysis matrix of all empty slots and their eligible teachers.

**Parameters:**
- `assignments` (Array)
- `teachers` (Array)
- `teacherIndex` (Map)
- `emptySlots` (Array) - Indices of empty slots
- `workloadMap` (Object)

**Returns:**
```javascript
[
  {
    assignmentIdx: 0,
    date: '2026-05-25',
    session: 1,
    grade: '12',
    exam: 'Accounting',
    venue: '1',
    timeshift: 2.5,
    preferredTeachers: ['Smith', 'Jones'],
    eligibleTeachers: ['Smith', 'Jones', 'Williams'],
    eligibleCount: 3
  },
  // ... more assignments
]
```

---

## MODULE 5: RANKING & SELECTION

### rankTeacherForSlot(teacherName, assignment, workloadMap, teacherIndex)
Calculates fit score (0-100) for teacher in slot.

**Parameters:**
- `teacherName` (string)
- `assignment` (Object)
- `workloadMap` (Object)
- `teacherIndex` (Map)

**Returns:**
- number (0-100)

**Scoring Factors:**
- Grade match (40%)
- Current workload (40%)
- Language match (10%)
- Session load (10%)

**Example:**
```javascript
const score = rankTeacherForSlot('Smith', assignment, workloadMap, teacherIndex);
// → 82 (good fit)
```

---

### sortTeachersByRank(candidateTeachers, assignment, workloadMap, teacherIndex)
Sorts candidates by ranking score.

**Parameters:**
- `candidateTeachers` (Array<string>)
- `assignment` (Object)
- `workloadMap` (Object)
- `teacherIndex` (Map)

**Returns:**
- Array of teacher names sorted by score (best → worst)

---

### selectBestTeacher(assignment, assignments, teachers, workloadMap, teacherIndex)
Selects best teacher using 3-tier ranking system.

**Tier 1:** Grade-matched teachers with lowest workload  
**Tier 2:** ROTATE teachers with lowest workload  
**Tier 3:** Any eligible teacher with lowest workload  

**Parameters:**
- `assignment` (Object)
- `assignments` (Array)
- `teachers` (Array)
- `workloadMap` (Object)
- `teacherIndex` (Map)

**Returns:**
- string (teacher name) | null

---

## MODULE 6: ASSIGNMENT OPERATIONS

### assignTeacherToSlot(assignmentIdx, teacherName, assignments, workloadMap)
Assigns teacher to slot and updates workload.

**Parameters:**
- `assignmentIdx` (number)
- `teacherName` (string)
- `assignments` (Array) - Modified in place
- `workloadMap` (Object) - Modified in place

**Returns:**
- boolean (success)

**Example:**
```javascript
assignTeacherToSlot(0, 'Smith', assignments, workloadMap);
// assignments[0].educator = 'Smith'
// workloadMap['Smith'].totalHours += 2.5
```

---

### unassignTeacher(assignmentIdx, assignments, workloadMap)
Removes teacher from slot and updates workload.

**Parameters:**
- `assignmentIdx` (number)
- `assignments` (Array)
- `workloadMap` (Object)

**Returns:**
- boolean (success)

---

## MODULE 7: MAIN SCHEDULING ALGORITHM

### scheduleAssignments(assignments, teachers, options)
Main function - performs complete scheduling.

**Parameters:**
- `assignments` (Array)
- `teachers` (Array)
- `options` (Object) - Optional configuration

**Returns:**
```javascript
{
  assignments: Array,        // Updated assignments with educators
  statistics: Object,        // Schedule statistics
  teacherStats: Object,      // Per-teacher breakdown
  report: Object,           // Detailed report
  warnings: Array,          // List of warnings
  log: Array,              // Operation log
  history: Array,          // Change history
  status: "success" | "partial" | "failed"
}
```

**Options (all optional):**
```javascript
{
  algorithm: 'greedy',              // or 'backtracking'
  enableLoadBalancing: true,
  targetVariance: 0.3,              // 30% variance acceptable
  maxConflictIterations: 10,
  weights: {
    gradeMatch: 0.40,
    workload: 0.40,
    language: 0.10,
    sessionLoad: 0.10
  },
  enforceGradeMatch: false,
  timeout: 30000                    // 30 seconds
}
```

**Example:**
```javascript
const result = scheduleAssignments(assignments, teachers, {
  enableLoadBalancing: true,
  targetVariance: 0.25
});

console.log(`Assigned: ${result.statistics.assignedSlots} of ${result.statistics.totalSlots}`);
console.log('Warnings:', result.warnings);
```

**Output Structure:**
```javascript
{
  statistics: {
    totalSlots: 500,
    assignedSlots: 495,
    unassignedSlots: 5,
    assignmentPercentage: 99,
    totalTeachers: 40,
    assignedTeachers: 35,
    gradeDistribution: { '8': 50, '9': 75, '10': 100, ... },
    sessionDistribution: { '1': 250, '2': 250 }
  },
  
  teacherStats: {
    'Smith': {
      totalHours: 18.5,
      slotCount: 8,
      datesScheduled: ['2026-05-25', '2026-05-26'],
      gradesAssigned: ['12'],
      sessionCount: 8,
      averageSessionLoad: '2.3'
    },
    // ... more teachers
  },
  
  report: {
    summary: 'Successfully scheduled 495 of 500 slots (99%)',
    totalSlots: 500,
    assignedSlots: 495,
    unassignedSlots: 5,
    duration: '2.45s',
    conflicts: 0,
    conflictIterations: 0,
    unresolvable: [...]
  },
  
  warnings: [
    {
      type: 'overloaded',
      teacher: 'Smith',
      hours: 32,
      message: 'Smith assigned 32 hours (above 30)'
    },
    // ... more warnings
  ]
}
```

---

## MODULE 8: VALIDATION & REPORTING

### validateSchedule(assignments)
Final validation of complete schedule.

**Parameters:**
- `assignments` (Array)

**Returns:**
```javascript
{
  isValid: boolean,
  violations: Array
}
```

---

### generateStatistics(assignments, teachers)
Creates schedule statistics.

**Returns:**
```javascript
{
  totalSlots: number,
  assignedSlots: number,
  unassignedSlots: number,
  assignmentPercentage: number,
  totalTeachers: number,
  assignedTeachers: number,
  gradeDistribution: Object,
  sessionDistribution: Object
}
```

---

### generateTeacherStats(assignments, workloadMap)
Creates per-teacher statistics.

**Returns:**
```javascript
{
  'Smith': {
    totalHours: number,
    slotCount: number,
    datesScheduled: Array<string>,
    gradesAssigned: Array<string>,
    sessionCount: number,
    averageSessionLoad: string
  },
  // ... more teachers
}
```

---

### generateWarnings(assignments, workloadMap)
Identifies potential issues with schedule.

**Returns:**
- Array of warning objects

**Warning Types:**
- `overloaded` - Teacher has >35 hours
- `unassigned_slots` - Slots without educators
- `high_workload_variance` - Unbalanced distribution

---

## 🔧 UTILITIES MODULE

### utilities.formatDate(date, format)
Formats date string.

**Formats:**
- `'short'` → '05/25/26'
- `'long'` → 'Mon, May 25, 2026'
- `'time'` → '14:30:45'

---

### utilities.formatNumber(num, decimals)
Adds thousand separators.

```javascript
utilities.formatNumber(1500000, 2);
// → '1,500,000.00'
```

---

### utilities.isValidEmail(email)
Validates email format.

---

### utilities.isValidDate(dateStr)
Validates YYYY-MM-DD format.

---

### utilities.downloadFile(data, filename, type)
Downloads file to user's computer.

```javascript
utilities.downloadFile(jsonString, 'data.json', 'application/json');
```

---

## 🔔 NOTIFICATIONS MODULE

### notifications.success(message, duration)
Shows green success toast.

```javascript
notifications.success('Data saved!', 3000);
```

---

### notifications.error(message, duration)
Shows red error toast.

---

### notifications.warning(message, duration)
Shows yellow warning toast.

---

### notifications.info(message, duration)
Shows blue info toast.

---

## 🐛 ERROR HANDLER

### errorHandler.toggleDebug()
Enables detailed console logging.

```javascript
errorHandler.toggleDebug();
// Now all errors and operations logged to console
```

---

### errorHandler.getErrors()
Gets list of all caught errors.

```javascript
const errors = errorHandler.getErrors();
console.table(errors);
```

---

### errorHandler.exportErrors()
Downloads error log as JSON file.

---

## 📊 DEBUG UTILITIES

### debug.stats()
Displays app statistics in console table.

```javascript
debug.stats();
// Shows: Total Assignments, Assigned, Firebase Ready, Errors, etc.
```

---

### debug.getState()
Returns complete app state object.

---

### debug.exportData()
Downloads all app data as JSON.

---

## ⚙️ CONFIGURATION

### schedulingConfig
Default configuration object:

```javascript
schedulingConfig = {
  algorithm: 'greedy',
  enableLoadBalancing: true,
  targetVariance: 0.3,
  maxSwaps: 10,
  maxConflictIterations: 10,
  conflictStrategy: 'unassign',
  weights: {
    gradeMatch: 0.40,
    workload: 0.40,
    language: 0.10,
    sessionLoad: 0.10
  },
  maxHoursPerTeacher: 40,
  enforceGradeMatch: false,
  timeout: 30000,
  logLevel: 'info',
  captureTrace: true
}
```

**Customize before scheduling:**
```javascript
schedulingConfig.targetVariance = 0.2; // Stricter balance
schedulingConfig.maxHoursPerTeacher = 30;
const result = scheduleAssignments(assignments, teachers);
```

---

## 🎯 COMPLETE WORKFLOW EXAMPLE

```javascript
// 1. Validate inputs
const assignValidation = validateAssignments(assignments);
const teachValidation = validateTeachers(teachers);

if (!assignValidation.isValid || !teachValidation.isValid) {
  console.error('Invalid data');
  return;
}

// 2. Prepare data
const normalized = normalizeDates(assignments);
const teacherIndex = buildTeacherIndex(teachers);

// 3. Analyze
const emptySlots = identifyEmptySlots(normalized);
const workloadMap = buildWorkloadMap(normalized, teachers);
const eligibility = buildEligibilityMatrix(
  normalized, teachers, teacherIndex, emptySlots, workloadMap
);

console.log(`Found ${emptySlots.length} empty slots to fill`);

// 4. Schedule
const result = scheduleAssignments(normalized, teachers, {
  enableLoadBalancing: true,
  targetVariance: 0.25
});

// 5. Report
console.log(`Assignment rate: ${result.statistics.assignmentPercentage}%`);
console.log('Warnings:', result.warnings);
console.log('Statistics:', result.statistics);

// 6. Export or save
if (result.status === 'success') {
  console.log('✓ Scheduling complete!');
  // Save result.assignments to database
}
```

---

## 📞 Error Messages & Solutions

### "No eligible teachers for slot"
- **Cause:** Teacher grade/constraints don't match
- **Solution:** Check teacher registerClass matches assignment grade
- **Code:** Ensure `teacher.registerClass === assignment.grade` or `'ROTATE'`

### "Conflict detected"
- **Cause:** Same teacher in same date+session twice
- **Solution:** Will auto-resolve, but check if unresolvable
- **Code:** Check `result.report.conflicts`

### "Too many iterations - possible circular conflict"
- **Cause:** Complex constraint interactions
- **Solution:** Relax constraints or increase `maxConflictIterations`
- **Code:** `schedulingConfig.maxConflictIterations = 20`

---

## 🔗 Related Documents

- **FIRESTORE.md** - Cloud persistence setup
- **DEPLOYMENT.md** - Hosting & deployment
- **README.md** - Feature overview
- **QUICKSTART.md** - User guide

---

**Last Updated:** May 2026  
**Version:** 1.0  
**Functions:** 38+  
**Modules:** 8
