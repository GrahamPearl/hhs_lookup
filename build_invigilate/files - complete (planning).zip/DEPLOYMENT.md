# Deployment Guide - Exam Scheduler

## 📋 Overview

This guide shows how to deploy the Exam Scheduler app to production. Choose the option that fits your needs.

---

## 🚀 Quick Deployment (Recommended for Getting Started)

### Option 1: Firebase Hosting (Free, Built-in with Firestore)

#### Step 1: Install Firebase CLI
```bash
npm install -g firebase-tools
```

#### Step 2: Login to Firebase
```bash
firebase login
```

#### Step 3: Initialize Hosting Project
```bash
firebase init hosting
```

When prompted:
```
? What do you want to use as your public directory? public
? Configure as a single-page app (rewrite all urls to index.html)? Yes
? Set up automatic builds and deploys with GitHub? No (or Yes if you want)
```

#### Step 4: Prepare Files
```bash
# Copy your HTML file to the public folder
cp index.html public/
cp scheduling-engine-part1.js public/
cp scheduling-engine-part2.js public/
```

#### Step 5: Deploy
```bash
firebase deploy --only hosting
```

You'll get a live URL:
```
✓ Deploy complete!
Hosting URL: https://your-project.web.app
```

**Advantages:**
- ✅ Free tier available
- ✅ Automatic HTTPS/SSL
- ✅ CDN worldwide
- ✅ No separate Firebase config needed
- ✅ Easy to update

---

### Option 2: Netlify (Easy, Good Performance)

#### Step 1: Prepare Files
Create this folder structure:
```
exam-scheduler/
├── index.html
├── scheduling-engine-part1.js
├── scheduling-engine-part2.js
└── netlify.toml (optional)
```

#### Step 2: Create netlify.toml (Optional)
```toml
[build]
  command = "echo 'No build needed'"
  publish = "."

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[context.production]
  command = "echo 'Production'"
```

#### Step 3: Deploy
**Option A: Using Git**
1. Push code to GitHub
2. Go to https://app.netlify.com
3. Click "New site from Git"
4. Connect GitHub repo
5. Deploy automatically

**Option B: Drag & Drop**
1. Go to https://app.netlify.com
2. Drag folder into deploy area
3. Done! You get a live URL instantly

**Advantages:**
- ✅ Free tier with custom domain
- ✅ Automatic HTTPS
- ✅ Continuous deployment from Git
- ✅ Great performance
- ✅ Simple interface

---

### Option 3: GitHub Pages (Free, Simple)

#### Step 1: Create GitHub Repository
1. Go to https://github.com/new
2. Repository name: `exam-scheduler`
3. Create repository

#### Step 2: Push Files
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/exam-scheduler.git
git push -u origin main
```

#### Step 3: Enable GitHub Pages
1. Go to repository **Settings**
2. Scroll to **Pages**
3. Source: `main` branch
4. Save

Your site is live at: `https://your-username.github.io/exam-scheduler`

**Advantages:**
- ✅ Completely free
- ✅ Uses Git for version control
- ✅ Automatic HTTPS
- ✅ Easy to update

**Limitations:**
- ❌ No server-side functionality
- ❌ No backend API

---

### Option 4: Vercel (Modern, Very Fast)

#### Step 1: Prepare Project
```bash
mkdir exam-scheduler
cd exam-scheduler
# Add your HTML and JS files
```

#### Step 2: Deploy with Vercel CLI
```bash
npm i -g vercel
vercel
```

Follow prompts to connect your account and deploy.

Or use GitHub:
1. Push to GitHub
2. Import project into https://vercel.com
3. Auto-deploying on every push

**Advantages:**
- ✅ Extremely fast (edge locations worldwide)
- ✅ Automatic deployments
- ✅ Free tier
- ✅ Great for static sites

---

## 🏢 Self-Hosted Deployment

### Option 5: Your Own Web Server

#### Linux Server (Nginx Example)

**Step 1: SSH into Server**
```bash
ssh user@your-server-ip
```

**Step 2: Install Nginx**
```bash
sudo apt update
sudo apt install nginx
```

**Step 3: Upload Files**
```bash
# From your computer:
scp index.html user@server:/tmp/
scp scheduling-engine-*.js user@server:/tmp/
```

**Step 4: Configure Nginx**
```bash
sudo nano /etc/nginx/sites-available/default
```

Replace with:
```nginx
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    
    server_name _;
    
    root /var/www/exam-scheduler;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
}
```

**Step 5: Move Files**
```bash
sudo mkdir -p /var/www/exam-scheduler
sudo mv /tmp/index.html /var/www/exam-scheduler/
sudo mv /tmp/scheduling-engine-*.js /var/www/exam-scheduler/
sudo chown -R www-data:www-data /var/www/exam-scheduler
```

**Step 6: Enable HTTPS (Let's Encrypt)**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

**Step 7: Restart Nginx**
```bash
sudo systemctl restart nginx
```

Your site is live at: `https://yourdomain.com`

---

## 🔒 Enable HTTPS on All Platforms

### Using Let's Encrypt (Free SSL)

Most platforms handle this automatically:
- ✅ Firebase Hosting: Automatic
- ✅ Netlify: Automatic
- ✅ Vercel: Automatic
- ✅ GitHub Pages: Automatic
- ✅ Nginx (above): Manual with certbot

### Custom Domain
1. Buy domain (GoDaddy, NameCheap, etc.)
2. Update DNS to point to your hosting
3. Enable HTTPS in hosting settings
4. Done!

---

## 📦 Production Checklist

Before going live:

- [ ] Configure Firebase with your credentials
- [ ] Test all features (upload, preview, save)
- [ ] Test offline mode (disconnect WiFi, test)
- [ ] Check Firestore security rules are correct
- [ ] Enable HTTPS/SSL
- [ ] Test on mobile devices
- [ ] Monitor Firebase console for errors
- [ ] Set up error logging (optional)
- [ ] Test with real data
- [ ] Have a backup plan

---

## 🚨 Production Security

### Firebase Config Exposure
⚠️ Your Firebase `apiKey` is visible in code. This is **normal and expected**.

The key is restricted by:
- Firestore Security Rules (you control this)
- Allowed domains in Firebase Console
- App-specific restrictions

**What it CANNOT do:**
- ❌ Access other Firebase projects
- ❌ Delete your database
- ❌ Access user passwords
- ❌ Bypass security rules

### Recommended Security

1. **Restrict Firestore Rules**
   - Only allow authenticated users
   - Use the rules provided in FIRESTORE.md

2. **Monitor Usage**
   - Firebase Console > Analytics
   - Set up billing alerts
   - Monitor for suspicious activity

3. **Enable Authentication**
   - Google Sign-in
   - Email/password
   - Custom authentication

4. **Regular Backups**
   - Firebase Console > Backups
   - Or export data regularly

---

## 📊 Monitoring & Maintenance

### Monitor Performance
```
Firebase Console:
├── Firestore > Usage
├── Storage
├── Analytics
└── Quotas & Limits
```

### Monitor Errors
1. Check browser console (F12)
2. Firebase Console > Logs
3. Set up custom error logging

### Update App
1. Update source files
2. Redeploy to hosting
3. Changes live immediately

### Backup Data
```bash
# Firebase CLI:
firebase firestore:export backup-folder

# Scheduled backups:
Firebase Console > Backups > Create scheduled backup
```

---

## 🎯 Hosting Comparison

| Feature | Firebase | Netlify | GitHub Pages | Vercel |
|---------|----------|---------|--------------|--------|
| **Cost** | Free | Free | Free | Free |
| **HTTPS** | ✅ Automatic | ✅ Automatic | ✅ Automatic | ✅ Automatic |
| **Custom Domain** | ✅ | ✅ | ✅ | ✅ |
| **Uptime SLA** | 99.95% | 99.99% | 99.99% | 99.99% |
| **Bandwidth** | 360 GB/mo free | Unlimited* | Unlimited | Unlimited |
| **Setup Time** | ~5 min | ~2 min | ~5 min | ~2 min |
| **Built-in DB** | ✅ | ❌ | ❌ | ❌ |
| **Environment Vars** | ✅ | ✅ | ❌ | ✅ |

*Netlify free tier: 100 GB/month data out

---

## 🆘 Troubleshooting Deployment

### Issue: 404 Not Found Error
**Solution:** Make sure `index.html` is in root directory
```bash
ls -la public/
# Should show: index.html, scheduling-engine-*.js
```

### Issue: Firestore Not Saving
**Check:**
1. Firebase config is correct
2. Security rules allow writes
3. Firebase project matches config
4. Check browser console for errors

### Issue: Slow Loading
**Optimize:**
1. Enable CDN (most platforms do this)
2. Minify JavaScript
3. Compress images
4. Cache headers

### Issue: CORS Error
**Solution:**
- This is normal for Firestore
- Firebase handles CORS automatically
- No additional configuration needed

---

## 📱 Mobile Deployment

### Install as Web App
1. Open app in mobile browser
2. Chrome: Menu > "Add to Home Screen"
3. Safari: Share > "Add to Home Screen"
4. Works offline with cached data!

### Mobile Optimization
The app is already responsive:
- ✅ Works on phones
- ✅ Works on tablets
- ✅ Optimized touch targets
- ✅ Offline access

---

## 🔄 Continuous Deployment (Optional)

### GitHub Actions Auto-Deploy
Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Firebase

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: FirebaseExtended/action-hosting-deploy@v0
        with:
          repoToken: '${{ secrets.GITHUB_TOKEN }}'
          firebaseServiceAccount: '${{ secrets.FIREBASE_SERVICE_ACCOUNT }}'
          channelId: live
          projectId: your-project-id
```

Now every push to `main` deploys automatically!

---

## 💰 Cost Estimation

### Monthly Costs

**Small Deployment (< 1000 users/month)**
- Firebase: FREE
- Hosting: FREE
- Custom domain: ~$10/year
- **Total: $0/month** ✅

**Medium Deployment (1000-10000 users/month)**
- Firebase: $0 (free tier)
- Hosting: $0 (included)
- Custom domain: ~$10/year
- **Total: $0/month** ✅

**Large Deployment (> 10000 users/month)**
- Firebase: ~$20-100/month
- Hosting: $0 (included)
- Custom domain: ~$10/year
- **Total: $20-100/month**

See Firebase pricing: https://firebase.google.com/pricing

---

## 📞 Support & Documentation

- **Firebase Docs**: https://firebase.google.com/docs
- **Netlify Docs**: https://docs.netlify.com
- **Vercel Docs**: https://vercel.com/docs
- **GitHub Pages**: https://pages.github.com

---

**Last Updated**: May 2026  
**Version**: 1.0
