# Firebase & Firestore Configuration Guide

## 🔧 Complete Setup Instructions

This guide provides step-by-step instructions to set up Firebase and Firestore for the Exam Scheduler app.

---

## STEP 1: Create Firebase Project

### 1.1 Visit Firebase Console
Go to: **https://console.firebase.google.com**

### 1.2 Create New Project
1. Click **"Create Project"** or **"Add Project"**
2. Enter project name: `Exam Scheduler` (or your preference)
3. Accept terms
4. Click **"Continue"**

### 1.3 Google Analytics (Optional)
- You can enable or disable
- For development: disable is fine
- Click **"Create Project"**

### 1.4 Wait for Setup
- Takes 1-2 minutes
- You'll see "Your Firebase project is ready"

---

## STEP 2: Create Firestore Database

### 2.1 Go to Firestore
In Firebase Console, go to:
**Build** (left menu) → **Firestore Database**

### 2.2 Create Database
Click **"Create Database"**

### 2.3 Choose Mode
Select one:

**Option A: Test Mode (Development)**
- Allow all reads/writes
- Auto-expires in 30 days
- Perfect for testing
- ⚠️ NOT secure for production

**Option B: Production Mode**
- Requires security rules
- More secure
- Recommended for production

**For now, select Test Mode** (we'll update rules before going live)

### 2.4 Choose Location
Select region closest to your users:
- US: `us-central1`
- EU: `europe-west1`
- Asia: `asia-southeast1`

Click **"Create Database"**

### 2.5 Wait for Initialization
Takes 30-60 seconds. You'll see an empty Firestore interface.

---

## STEP 3: Create Collection

### 3.1 Create Assignments Collection
In Firestore, click **"Start Collection"**

**Collection ID:** `assignments` (exactly this)

### 3.2 Auto ID (Optional First Document)
You can:
- Add a sample document now
- Or skip - documents auto-create when uploading

If adding sample:
1. Click **"Auto ID"**
2. Add field: `date` = `2026-05-25`
3. Add field: `educator` = `Smith`
4. Click **"Save"**

Then you can delete this sample later.

---

## STEP 4: Security Rules

### 4.1 Go to Rules Tab
Firestore → **Rules** tab

### 4.2 Copy Test Mode Rules (Development)

**⚠️ WARNING**: Only for development! Auto-expires July 1, 2026.

```firestore
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.time < timestamp.date(2026, 7, 1);
    }
  }
}
```

### 4.3 Copy Production Rules (Later)

When deploying to production, replace with this:

```firestore
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Assignments collection - authenticated users
    match /assignments/{document=**} {
      // Allow read for authenticated users
      allow read: if request.auth != null;
      
      // Allow create with required fields
      allow create: if request.auth != null 
                    && request.resource.data.keys().hasAll([
                      'date', 'session', 'grade', 'exam', 'venue', 'timeshift'
                    ]);
      
      // Allow update for authenticated users
      allow update: if request.auth != null;
      
      // Allow delete for authenticated users
      allow delete: if request.auth != null;
    }
    
    // Allow metadata access (for connection check)
    match /_metadata/{document=**} {
      allow read, write: if request.auth != null;
    }
    
    // Deny everything else
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

### 4.4 Publish Rules
1. Paste rules into editor
2. Click **"Publish"**
3. Confirm if prompted

---

## STEP 5: Get Firebase Config

### 5.1 Go to Project Settings
Firebase Console → **⚙️ Project Settings** (top right)

### 5.2 Click "Your Apps"
Look for your project name, click **"Your Apps"** section

### 5.3 Add Web App
If not already present:
1. Click **"<> Add App"** (web icon)
2. App nickname: `Exam Scheduler`
3. Click **"Register App"**

### 5.4 Copy Config
You'll see code like:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyDxxxxxxxxxxxxxxxxxxx",
  authDomain: "exam-scheduler-xxxxx.firebaseapp.com",
  projectId: "exam-scheduler-xxxxx",
  storageBucket: "exam-scheduler-xxxxx.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdefg1234567890"
};
```

**Copy the entire config object** (we'll need it next)

---

## STEP 6: Configure the App

### 6.1 Option A: Browser Console (Quick)

1. Open the Exam Scheduler app in browser
2. Press **F12** to open Developer Tools
3. Click **"Console"** tab
4. Paste and run:

```javascript
firestoreManager.saveConfig({
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
});
```

Replace with your actual values from Step 5.4

5. Press **Enter**
6. You should see: `undefined` (that's OK)
7. **Reload the page** (F5)
8. Check console - should show `✓ Firebase initialized successfully`

### 6.2 Option B: Edit HTML File (Permanent)

Before uploading to server:

1. Open `index.html` in text editor
2. Find the section near end of `<body>`:
```html
<script>
document.addEventListener('DOMContentLoaded', () => {
    firestoreManager.init().then(initialized => {
```

3. Add this **before** that code:
```javascript
<script>
// Configure Firebase
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-id",
  appId: "your-app-id"
};

// Save config on startup
document.addEventListener('DOMContentLoaded', () => {
  firestoreManager.init(firebaseConfig);
});
</script>
```

4. Replace with your actual config from Step 5.4
5. Save file
6. Upload to server

---

## STEP 7: Test Connection

### 7.1 Upload Test File
1. Open app in browser
2. Go to **"Upload Data"** tab
3. Create a small test Excel file with 5-10 rows
4. Click **"Load & Preview"**
5. Click **"Save to Database"**

### 7.2 Check for Success
You should see:
- ✓ `Saving to database... 5/5`
- ✓ `Saved N assignments successfully!`

### 7.3 Verify in Firestore
In Firebase Console:
1. Go to **Firestore Database**
2. Click **"assignments"** collection
3. You should see 5 documents with your data!

If you see data → ✅ **Setup successful!**

---

## 🔍 Indexes (Auto-Creation)

Firestore can auto-create indexes when needed. First time you run certain queries, it may say:

"Composite index required"

Click **"Create index"** → Wait for creation (usually 1-2 minutes)

### Recommended Indexes to Pre-Create

**Index 1: Educator + Date Sorting**
1. Firestore → **Indexes** tab
2. Click **"Create Index"**
3. Collection: `assignments`
4. Field 1: `educator` (Ascending)
5. Field 2: `date` (Descending)
6. Click **"Create"**

**Index 2: Date + Session**
1. Collection: `assignments`
2. Field 1: `date` (Ascending)
3. Field 2: `session` (Ascending)
4. Click **"Create"**

**Index 3: Year-Month**
1. Collection: `assignments`
2. Field: `year_month` (Descending)
3. Click **"Create"**

---

## ⚠️ Troubleshooting

### Issue: "Firebase config not found"

**In Console:**
```javascript
firestoreManager.state.isInitialized
// Should return: true

firestoreManager.state.isOnline
// Should return: true (if connected)
```

**If false:**
1. Check config is correct (no typos)
2. Check project ID matches
3. Try again: `firestoreManager.init(yourConfig)`

---

### Issue: "Permission denied" When Saving

**Cause:** Security rules too strict

**Solution:**
1. Go to Firestore → Rules
2. Switch to **Test Mode** temporarily
3. Paste test rules from Step 4.2
4. Click **"Publish"**
5. Try saving again

Then investigate your rules.

---

### Issue: Data Not Appearing

**Check:**
1. No JavaScript errors (F12 Console)
2. Rules allow writes (check Rules tab)
3. Collection is exactly named `assignments`
4. Firebase config is correct

**Test:**
```javascript
// In console:
firestoreManager.state.db.collection('assignments').add({
  test: 'data',
  date: new Date()
}).then(() => console.log('✓ Write successful'));
```

---

### Issue: Real-time Updates Not Working

**Cause:** Real-time listeners need online connection

**Solution:**
1. Check internet connection
2. Try going offline then online
3. Firestore auto-syncs when back online
4. Check offline queue: `debug.stats()`

---

## 📱 Mobile Considerations

### App Size
- HTML: ~300KB
- JavaScript: ~50KB
- Total: ~350KB
- **Works offline immediately**

### Mobile Testing
```javascript
// Check if mobile:
const isMobile = /iPhone|iPad|Android/.test(navigator.userAgent);

// Check offline:
console.log('Online:', navigator.onLine);

// Check sync status:
firestoreManager.getSyncStatus();
```

---

## 💰 Firestore Pricing

### Free Tier (Spark Plan)
- 1 GB storage
- 50,000 reads/day
- 20,000 writes/day
- Perfect for small schools

### Paid Tier (Blaze)
- Pay as you go
- ~$0.06 per 100,000 reads
- $0.18 per 100,000 writes
- Better for large deployments

**Monitor usage:**
Firestore → **Usage** tab

---

## 🔐 Security Best Practices

### Never
❌ Share your Firebase config in public repos  
❌ Commit API keys  
❌ Use admin keys in frontend code  

### Do
✅ Use limited keys (frontend API key)  
✅ Restrict in Firebase Console  
✅ Use security rules  
✅ Monitor access  

### API Key Restrictions (Optional)
Firebase Console → **Project Settings** → **API Keys**

Click your key → **Edit**

Set restrictions:
- Application restrictions: Web apps
- API restrictions: Firestore API only

---

## 📊 Monitoring & Maintenance

### Regular Checks
1. **Usage Dashboard**
   - Firestore → Usage
   - Monitor read/write operations
   - Check storage usage

2. **Security**
   - Review security rules monthly
   - Check activity logs
   - Enable audit logging

3. **Backups**
   - Firestore → Backups
   - Set up scheduled backups
   - Export data periodically

### Export Data
```bash
# Using Firebase CLI
firebase firestore:export backup-folder

# Then download backup-folder
```

---

## 🚀 Production Checklist

Before going live:

- [ ] Security rules updated (not test mode)
- [ ] API key restrictions set
- [ ] Indexes created for main queries
- [ ] Data validated (no garbage rows)
- [ ] Backups scheduled
- [ ] Error handling tested
- [ ] Offline mode tested
- [ ] Performance acceptable
- [ ] Mobile tested
- [ ] Team trained

---

## 📞 Support Resources

- **Firebase Docs:** https://firebase.google.com/docs
- **Firestore Guide:** https://firebase.google.com/docs/firestore
- **Security Rules:** https://firebase.google.com/docs/firestore/security/start
- **Console Status:** https://status.firebase.google.com

---

## ✅ Verification Checklist

After setup, verify:

```javascript
// In browser console:

// 1. Firebase initialized
firestoreManager.state.isInitialized
// → true

// 2. Online status
firestoreManager.state.isOnline
// → true

// 3. Database connected
firestoreManager.state.db
// → [object Object] (not null)

// 4. Upload test data
// Upload 5 assignments, save to Firestore

// 5. Check Firestore Console
// You should see 5 new documents in assignments collection

// 6. Real-time updates
// Check if Dashboard updates when data is saved
```

All checks pass → ✅ **Setup complete!**

---

**Last Updated:** May 2026  
**Version:** 1.0  
**Firebase SDK:** v11.0.1
