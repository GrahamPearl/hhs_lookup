# Firestore Setup & Configuration Guide

## 📋 Overview

The Exam Scheduler app uses Firestore (Firebase NoSQL database) to persist exam assignment data in the cloud. This guide walks you through setting up Firebase and configuring your app.

---

## 🔧 Step 1: Create Firebase Project

### 1.1 Go to Firebase Console
- Visit: https://console.firebase.google.com
- Click "Create Project" or "Add Project"

### 1.2 Project Details
```
Project Name: Exam Scheduler
(or your preferred name)

Analytics: Optional (can disable)
Region: Choose closest to your location
```

### 1.3 Wait for Project Creation
- Takes 1-2 minutes
- You'll see "Your Firebase project is ready"

---

## 🗄️ Step 2: Set Up Firestore Database

### 2.1 Create Firestore Database
1. In Firebase Console, go to **Build > Firestore Database**
2. Click **Create Database**

### 2.2 Database Configuration
```
Location: Choose closest region
Production or Test Mode:
→ Start in Test Mode (for development)
→ Production Mode (for live use - requires security rules)
```

### 2.3 Enable Firestore
- Click **Create Database**
- Wait for initialization (30 seconds)
- You should see an empty Firestore database

---

## 📊 Step 3: Collection & Data Structure

### 3.1 Create Collection: `assignments`

In Firestore Console:
1. Click **Start Collection**
2. Collection ID: `assignments`
3. Click **Next**

### 3.2 Sample Document
Add a sample assignment document (optional, for testing):

```json
{
  "date": "2026-05-25",
  "session": 1,
  "grade": "12",
  "exam": "Accounting P1",
  "venue": "1",
  "educator": "Smith",
  "timeshift": 2.5,
  "educator_grade": "Grade 12",
  "is_zulu": false,
  "day_session_key": "2026-05-25_1",
  "educator_date_key": "Smith_2026-05-25",
  "year_month": "2026-05",
  "venue_session": "Venue1_2026-05-25_1",
  "uploadBatchId": "batch_20260514142530",
  "uploadedAt": "2026-05-14T14:25:30Z",
  "updatedAt": "2026-05-14T14:25:30Z",
  "source": "excel_upload"
}
```

Or skip this - documents are created automatically when uploading.

---

## 🔐 Step 4: Security Rules

### 4.1 Default Test Rules (Development Only)
⚠️ **Warning**: Test mode allows anyone to read/write. Use only for development!

```firestore
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.time < timestamp.date(2026, 7, 1);
    }
  }
}
```

### 4.2 Authenticated Rules (Recommended for Production)

If you want to add authentication:

```firestore
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Assignments collection - authenticated users only
    match /assignments/{document=**} {
      allow read: if request.auth != null;
      allow create: if request.auth != null 
                    && request.resource.data.keys().hasAll(['date', 'exam', 'venue']);
      allow update: if request.auth != null;
      allow delete: if request.auth != null;
    }
    
    // Metadata collection for sync status
    match /_metadata/{document=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
  }
}
```

### 4.3 Apply Rules

1. In Firebase Console: **Build > Firestore Database > Rules**
2. Replace default rules with above
3. Click **Publish**

---

## 🔑 Step 5: Get Firebase Config

### 5.1 Create Web App
1. In Firebase Console, go to **Project Settings** (⚙️)
2. Click **Your Apps** tab
3. Click **Add App > Web**
4. App nickname: `Exam Scheduler`
5. Click **Register App**

### 5.2 Copy Firebase Config
You'll see your config object:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_ID",
  appId: "YOUR_APP_ID"
};
```

**Save this config - you'll need it next.**

---

## 💻 Step 6: Configure Your App

### 6.1 Option A: Browser Console

Open your app in browser, press `F12` (Developer Tools), go to **Console**, and run:

```javascript
firestoreManager.saveConfig({
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_ID",
  appId: "YOUR_APP_ID"
});
```

The config is now saved in localStorage.

### 6.2 Option B: HTML File Edit

Before uploading the HTML file to your server, add this script at the bottom of the `<body>` tag, before closing `</body>`:

```html
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Your Firebase config
  const config = {
    apiKey: "YOUR_API_KEY",
    authDomain: "your-project.firebaseapp.com",
    projectId: "your-project-id",
    storageBucket: "your-project.appspot.com",
    messagingSenderId: "YOUR_MESSAGING_ID",
    appId: "YOUR_APP_ID"
  };
  
  // Initialize Firestore
  firestoreManager.init(config);
});
</script>
```

---

## 🔍 Step 7: Test Connection

### 7.1 Verify Firestore is Ready

1. Open your app
2. Go to **Upload Data** tab
3. Upload a test Excel file with 5-10 assignments
4. Click **Load & Preview**
5. Click **Save to Database**

You should see:
- `✓ Saving to database... X/Y`
- `✓ Saved N assignments successfully!`

### 7.2 Check Firestore Console

In Firestore:
1. Go to **assignments** collection
2. You should see documents appearing in real-time!
3. Click one to view the data

If you don't see documents:
- Check browser console (F12) for errors
- Verify your Firebase config is correct
- Check Firestore security rules allow writes

---

## 📋 Collection Structure Reference

### Collection: `assignments`

```
/assignments/{documentId}
├── date (string) - YYYY-MM-DD format
├── session (number) - 1, 2, 3
├── grade (string) - "8", "9", "10", "11", "12", "SUPP"
├── exam (string) - Subject name
├── venue (string/number) - Venue identifier
├── educator (string|null) - Teacher name
├── timeshift (number) - Duration in hours
├── educator_grade (string|null) - Teacher's grade level
├── is_zulu (boolean) - Language requirement
├── day_session_key (string) - Composite: "YYYY-MM-DD_session"
├── educator_date_key (string|null) - Composite: "name_YYYY-MM-DD"
├── year_month (string) - "YYYY-MM" for archive queries
├── venue_session (string) - Composite: "venue_date_session"
├── uploadBatchId (string) - Upload session ID
├── uploadedAt (timestamp) - Creation time
├── updatedAt (timestamp) - Last modified
└── source (string) - "excel_upload"
```

---

## 🔎 Firestore Indexes

The app uses these queries which may need indexes:

### Recommended Indexes to Create

**Index 1: Educator + Date**
```
Collection: assignments
Fields:
  - educator (Ascending)
  - date (Descending)
```

**Index 2: Date + Session**
```
Collection: assignments
Fields:
  - date (Ascending)
  - session (Ascending)
```

**Index 3: Year-Month (for archive queries)**
```
Collection: assignments
Fields:
  - year_month (Descending)
```

**To Create Indexes:**
1. Firebase Console > Firestore > Indexes
2. Click "Create Index"
3. Collection: `assignments`
4. Add fields as above
5. Click "Create"

Firestore will suggest indexes automatically when you first run queries.

---

## 🔄 Offline Mode & Sync

### How Offline Works

1. **Offline Queue**: When offline, changes are queued locally
2. **localStorage**: Uses browser storage for persistence
3. **Auto-sync**: When back online, queued changes sync automatically
4. **Status Indicator**: Top-right shows "Online" (green) or "Offline" (red)

### Offline Usage

```javascript
// See offline status
const status = firestoreManager.getSyncStatus();
console.log('Online:', status.isOnline);
console.log('Queued:', status.queueSize);

// Save works offline
uploadManager.saveToFirebase(); // Saves to localStorage automatically
```

---

## ⚠️ Troubleshooting

### Issue: "Firebase config not found"

**Solution:**
```javascript
// In browser console (F12):
firestoreManager.saveConfig({
  apiKey: "YOUR_API_KEY",
  authDomain: "...",
  // ... full config
});

// Then reload page
location.reload();
```

### Issue: "Permission denied" Error

**Solution:**
1. Check Firestore Security Rules in Firebase Console
2. Make sure rules allow reads/writes (or set to Test mode temporarily)
3. Verify the collection name is exactly `assignments`

### Issue: Data Not Appearing in Firestore

**Check:**
1. Is Firebase initialized? (Check browser console)
2. Are security rules blocking writes?
3. Is the Internet connection stable?
4. Try uploading again with smaller file (5 rows)

### Issue: Real-time Updates Not Working

**Solution:**
1. Firestore real-time listeners require online connection
2. Offline mode uses localStorage only
3. Listeners resume when back online

---

## 🛡️ Security Best Practices

### For Development
- Use Test Mode temporarily
- Restrict in time (auto-expires)
- Monitor security warnings in Firebase Console

### For Production
1. **Enable Authentication** (Google, Email, Custom)
2. **Restrict Rules** to authenticated users only
3. **Enable Firestore Backups** (Firebase Console > Backups)
4. **Monitor Usage** (Firebase Console > Quotas & Analytics)
5. **Set Up Alerts** for unusual activity

---

## 📊 Firestore Quotas & Limits

### Free Tier (Spark Plan)
- 1 GB storage (total)
- 50,000 reads/day
- 20,000 writes/day
- 20,000 deletes/day

### Paid Plan (Blaze)
- Pay-as-you-go
- Higher quotas
- Better for production

### Optimize Queries
- Use composite keys for fast filtering
- Avoid reading entire collection
- Delete old data periodically
- Monitor usage in Firebase Console

---

## 🎯 Next Steps

1. ✅ Create Firebase project
2. ✅ Set up Firestore database
3. ✅ Create security rules
4. ✅ Get Firebase config
5. ✅ Configure app with config
6. ✅ Test upload & save
7. 🔄 Deploy app to hosting

---

## 📚 Additional Resources

- **Firebase Docs**: https://firebase.google.com/docs
- **Firestore Guide**: https://firebase.google.com/docs/firestore
- **Security Rules**: https://firebase.google.com/docs/firestore/security/start
- **Authentication**: https://firebase.google.com/docs/auth

---

## ✉️ Support

If you encounter issues:

1. Check Firebase Console for error messages
2. Review browser console (F12 > Console tab)
3. Check Firestore security rules
4. Verify Firebase config is correct
5. Test with small dataset (5 rows)

---

**Last Updated**: May 2026  
**Version**: 1.0  
**Firebase SDK**: v11.0.1
